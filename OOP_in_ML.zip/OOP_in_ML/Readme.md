## Notebooks related to adding flavor of Object-oriented Programming (OOP) into ML

* [Implementation of a linear regression class with various types of methods - fit, predict, metrics, diagnostics, and outlier plots](https://github.com/tirthajyoti/Machine-Learning-with-Python/blob/master/OOP_in_ML/Class_MyLinearRegression.ipynb)

from need_for_speed.vehicle import Vehicle


class Motorcycle(Vehicle):
    pass


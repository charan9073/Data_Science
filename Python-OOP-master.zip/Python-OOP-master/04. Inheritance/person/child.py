from person.person import Person


class Child(Person):
    pass

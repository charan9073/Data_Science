class Animal:
    def eat(self):
        return "eating..."

class Dog(Animal):
    def bark(self):
        return "barking..."


# dog = Dog()
# animal= Animal()
# print(animal.eat())
# print(dog.eat())
# print(dog.bark())

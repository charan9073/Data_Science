from zoo.reptile import Reptile


class Lizard(Reptile):
    def __init__(self):
        super(Lizard, self).__init__()

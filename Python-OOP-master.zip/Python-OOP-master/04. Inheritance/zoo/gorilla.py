from zoo.mammal import Mammal


class Gorilla(Mammal):
    def __init__(self):
        super(Gorilla, self).__init__()
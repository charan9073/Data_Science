from zoo.mammal import Mammal


class Bear(Mammal):
    def __init__(self):
        super(Bear, self).__init__()

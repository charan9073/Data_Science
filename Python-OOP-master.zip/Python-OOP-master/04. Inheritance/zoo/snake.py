from zoo.reptile import Reptile


class Snake(Reptile):
    def __init__(self):
        super(Snake, self).__init__()
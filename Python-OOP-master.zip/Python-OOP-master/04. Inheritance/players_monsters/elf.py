from players_monsters.hero import Hero


class Elf(Hero):
    pass



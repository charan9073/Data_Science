from players_monsters.wizard import Wizard


class DarkWizard(Wizard):
    pass

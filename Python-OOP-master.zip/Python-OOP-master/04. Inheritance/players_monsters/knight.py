from players_monsters.hero import Hero


class Knight(Hero):
    pass
